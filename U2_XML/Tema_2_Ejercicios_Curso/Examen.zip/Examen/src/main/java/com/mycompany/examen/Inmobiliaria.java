package com.mycompany.examen;

import java.util.List;

/**
 *
 * @author usuario
 */
public class Inmobiliaria {
    private int identificador;
    private String nombre;
    private int numeroEmpleados;
    private List<Inmueble> inmuebles;

    public Inmobiliaria()
    {
    }

    public Inmobiliaria(int identificador, String nombre, int nEmpleados)
    {
        this.identificador = identificador;
        this.nombre = nombre;
        this.numeroEmpleados = nEmpleados;
    }

    public int getIdentificador()
    {
        return identificador;
    }

    public void setIdentificador(int identificador)
    {
        this.identificador = identificador;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public int getNumeroEmpleados()
    {
        return numeroEmpleados;
    }

    public void setNumeroEmpleados(int numeroEmpleados)
    {
        this.numeroEmpleados = numeroEmpleados;
    }
    
    public boolean añadirInmueble(Inmueble nuevoInmu){
        return this.inmuebles.add(nuevoInmu);
    }
    
    @Override
    public int hashCode()
    {
        int hash = 5;
        hash = 23 * hash + this.identificador;
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final Inmobiliaria other = (Inmobiliaria) obj;
        if (this.identificador != other.identificador)
            return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "Inmoviliaria{" + "identificador=" + identificador + ", nombre=" + nombre + ", nEmpleados=" + numeroEmpleados + '}';
    }
    

}
