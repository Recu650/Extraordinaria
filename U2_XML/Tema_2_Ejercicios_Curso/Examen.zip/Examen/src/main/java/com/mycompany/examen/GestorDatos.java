package com.mycompany.examen;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import org.w3c.dom.Node;

/**
 *
 * @author usuario
 */
public class GestorDatos
{
    private List<Inmobiliaria> inmoviliarias;
    public GestorDatos()
    {
    }

    public void modificarPrecios(int idInmo)
    {
        
    }

    public void leerInmobiliarias(Path ruta)
    {
        try{
            FileInputStream fis = new FileInputStream(ruta.toFile());
            DataInputStream dis = new DataInputStream(fis);
            while(true){
                Inmobiliaria in = new Inmobiliaria(dis.readInt(), dis.readUTF(), dis.readInt());
                if(this.inmoviliarias.contains(in) == false) this.inmoviliarias.add(in);
            }
        } catch (FileNotFoundException ex)
        {
            System.out.println(ex.toString());
        } catch (IOException ex)
        {
            //Final
        }
        
    }

    public void leerInmuebles(Path ruta)
    {
        
    }

//    private Inmobiliaria buscarPorId(int id)
//    {
//
//    }

    public void procesarDatosXML(Path ruta)
    {

    }

    public void añadirEtiquetaValoracion(Path ruta)
    {

    }

    public void guardarJASON(Path ruta)
    {

    }

//    public String mostrarDatosEncolumnados()
//    {
//
//    }
//
//    public String mostrarDatosOrdenadosEmpleados()
//    {
//
//    }
//
//    public String mostrarInmobiliariasOrdenadasPorMediaPrecios()
//    {
//
//    }
//
//    public Set<Inmobiliaria> getInmobiliaria()
//    {
//
//    }

    public void borrarEspaciosEnBlanco(Node nodo)
    {

    }

}
