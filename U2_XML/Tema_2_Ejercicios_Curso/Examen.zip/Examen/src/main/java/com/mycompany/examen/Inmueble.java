package com.mycompany.examen;

import java.util.Objects;

/**
 *
 * @author usuario
 */
public class Inmueble {
    private String nombre;
    private double precio;
    private String descripcion;
    private int idInmobiliaria;

    public Inmueble()
    {
    }

    public Inmueble(String nombre, double precio, String descripcion, int idInmobiliaria)
    {
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.idInmobiliaria = idInmobiliaria;
    }

    public int getIdInmobiliaria()
    {
        return idInmobiliaria;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public void setPrecio(double precio)
    {
        this.precio = precio;
    }

    public void setDescripcion(String descripcion)
    {
        this.descripcion = descripcion;
    }

    public double getPrecio()
    {
        return precio;
    }

    @Override
    public String toString()
    {
        return "Inmueble{" + "nombre=" + nombre + ", precio=" + precio + ", descripcion=" + descripcion + '}';
    }

    @Override
    public int hashCode()
    {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.nombre);
        hash = 79 * hash + (int) (Double.doubleToLongBits(this.precio) ^ (Double.doubleToLongBits(this.precio) >>> 32));
        hash = 79 * hash + Objects.hashCode(this.descripcion);
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final Inmueble other = (Inmueble) obj;
        if (Double.doubleToLongBits(this.precio) != Double.doubleToLongBits(other.precio))
            return false;
        if (!Objects.equals(this.nombre, other.nombre))
            return false;
        if (!Objects.equals(this.descripcion, other.descripcion))
            return false;
        return true;
    }
    
}
